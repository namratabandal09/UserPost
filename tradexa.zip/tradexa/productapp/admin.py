from django.contrib import admin
from .models.product import Product

# Register your models here.
admin.site.register(Product)